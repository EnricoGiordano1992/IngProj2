This archive has 2 directory:

- EXEC, that contains executable program;

- SOURCE, that contains source files.

to start the program, follow this instruction:

WINDOWS:

double click on proj.jar


LINUX:

open terminal, then execute this command in this path:

java -jar proj.jar


for more info, see PAPER.pdf 
